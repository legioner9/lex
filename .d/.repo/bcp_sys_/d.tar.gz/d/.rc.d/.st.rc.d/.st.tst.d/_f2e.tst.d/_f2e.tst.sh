#!/bin/bash

cd ~/.d/.rc.d/.st.rc.d/.st.tst.d/_f2e.tst.d || echo "cd ~/.d/.rc.d/.st.rc.d/.st.tst.d/_f2e.tst.d EXEC_FALI" >&2

_f2e file.txt
