#!/bin/bash

# cd ~/.d/.rc.d/.st.rc.d/.st.tst.d/_s2f.tst.d || echo "cd ~/.d/.rc.d/.st.rc.d/.st.tst.d/_s2f.tst.d EXEC_FALI" >&2
