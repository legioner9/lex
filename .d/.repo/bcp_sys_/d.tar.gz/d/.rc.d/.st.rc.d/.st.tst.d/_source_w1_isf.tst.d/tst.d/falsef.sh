#!/bin/bash

cd x