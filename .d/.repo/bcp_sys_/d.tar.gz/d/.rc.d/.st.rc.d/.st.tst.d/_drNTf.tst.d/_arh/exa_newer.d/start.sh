#!/bin/bash

dir=${HOME}/REPOBARE/_repo

cd ${dir} || echo "FAIL cd ${dir}" >&2