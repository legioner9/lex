#!/bin/bash

# if true; then
#     echo "_f2f"
# fi

cd ~/.st.rc.d/.st.tst.d/_f2f.tst.d || echo "cd ~/.st.rc.d/.st.tst.d/_f2f.tst.d EXEC_FALI" >&2

cp init.file res

# echo -e "${HLIGHT}--- exec: _f2f one two tst.file ---${NORMAL}" #start files
_f2f insert.file '{{reciver}}'  res

cat res
