#!/bin/bash

if _is_root ${HOME}; then
    echo "true"
fi
