#!/bin/bash

___XXX_TST_SH() {

    local sh_file=${HOME}/.st.rc.d/.st.sh.d/_XXX.sh
    local tst_file=${HOME}/.st.rc.d/.st.tst.d/_XXX.sh    
    local tst_dir=${HOME}/.st.rc.d/.st.tst.d/_XXX.tst.d
    local tst_dir_file=${tst_dir}/_XXX.tst.sh

    cd ${tst_dir} || echo "in file://${tst_dir_file} : EXEC_FAIL : cd ${tst_dir}" >&2

    if true; then
        echo "_XXX"
    fi

    : >res

    # cd tst.d || echo "in file://${tst_dir_file} : EXEC_FAIL : cd tst.dir" >&2

    # _XXX >/dev/null

    flag=1

    if ! diff -q res pre >/dev/null; then
        flag=0
    fi

    if [ 0 -eq "$flag" ]; then
        echo "in file://${tst_dir_file} fail" >&2
        diff res pre >&2
        return 1
    else
        echo "in file://${tst_dir_file} true"
        return 0
    fi
}

___XXX_TST_SH