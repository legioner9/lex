#!/bin/bash

if true; then
    echo "XXX"
fi
