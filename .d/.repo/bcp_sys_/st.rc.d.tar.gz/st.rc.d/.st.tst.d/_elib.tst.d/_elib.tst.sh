#!/bin/bash

# cd ~/.st.rc.d/.st.tst.d/_s2f.tst.d || echo "cd ~/.st.rc.d/.st.tst.d/_s2f.tst.d EXEC_FALI" >&2