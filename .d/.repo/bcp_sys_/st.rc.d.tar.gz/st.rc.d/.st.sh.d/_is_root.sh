#!/bin/bash

_is_root() {

    if [ "-h" == "$1" ]; then
        echo -e "
        ${FUNCNAME} is :: 
\$1 
[, \$2]
"
        return 0
    fi

    arg1="$1"
    if [[ -z "${arg1}" ]]; then
        echo "_is_root() : \$1 NOT_DEFINE : return 1" >&2
        return 1
    fi
    if [[ "/" == "${arg1:0:1}" ]]; then
        return 0
    else
        return 1
    fi

}
