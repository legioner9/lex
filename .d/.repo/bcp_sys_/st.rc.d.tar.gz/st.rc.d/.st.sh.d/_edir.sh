#!/bin/bash

_edir() {
    
    if [ "-h" == "$1" ]; then
        echo -e "
\$1 
[, \$2]
"
        return 0
    fi

    _edit ${HOME}/.st.rc.d/.st.sh.d

}
