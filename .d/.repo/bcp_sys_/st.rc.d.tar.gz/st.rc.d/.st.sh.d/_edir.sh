#!/bin/bash

_edir() {

    _edit ${HOME}/.st.rc.d/.st.sh.d

}
