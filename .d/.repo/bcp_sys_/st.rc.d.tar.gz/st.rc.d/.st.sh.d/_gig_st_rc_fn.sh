#!/bin/bash

_gig_st_rc_fn() {

    echo -e "${CYAN}--- start : ${FUNCNAME}() $@ ---${NORMAL}" #sistem info mesage

    if [ "-h" == "$1" ]; then
        echo -e "
MAIN: ${FUNCNAME} :: generate \$1 st_rc_fn like _XXX
\$1 name st_rc_fn
[, \$2]
"
        return 0
    fi

    cp ${HOME}/.st.rc.d/.st.sh.d/_XXX.sh ${HOME}/.st.rc.d/.st.sh.d/$1.sh

    _s2f $1 _XXX ${HOME}/.st.rc.d/.st.sh.d/$1.sh

    return 0

}
