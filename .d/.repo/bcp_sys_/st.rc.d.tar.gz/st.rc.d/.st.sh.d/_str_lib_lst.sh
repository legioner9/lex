#!/bin/bash

_str_lib_lst() {
    # echo -e "${CYAN}--- _str_lib_lst() ---${NORMAL}" #started functions

    local item

    for item in $(_f2e ${HOME}/.st.rc.d/.st.lst); do
        echo $(basename $item)
    done

}
