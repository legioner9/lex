#!/bin/bash

_elib() {

    _edit ${HOME}/.st.rc.d/.st.lst

}
