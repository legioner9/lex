#!/bin/bash

_elib() {

    if [ "-h" == "$1" ]; then
        echo -e "
        ${FUNCNAME} is :: 
\$1 
[, \$2]
"
        return 0
    fi

    _edit ${HOME}/.st.rc.d/.st.lst

}
