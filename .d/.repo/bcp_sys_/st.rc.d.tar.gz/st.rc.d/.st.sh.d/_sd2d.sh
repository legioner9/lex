#!/bin/bash

_sd2d() {

    echo -e "${CYAN}--- start : ${FUNCNAME}() $@ ---${NORMAL}" #sistem info mesage

    if [[ "-h" == "$1" ]]; then
        echo -e "
MAIN: ${FUNCNAME} :: cp dir \$3 to $(namedir \$3) with replace \$1 to \$2 in files and name node
\$1 
[, \$2]
CNTL: 
    _e : body fn : _edit ${HOME}/.st.rc.d/.st.sh.d/_sd2d.sh
    _t : tst_dir : _edit ${HOME}/.st.rc.d/.st.tst.d/_sd2d.tst.d
EXAM: 
    ${FUNCNAME}
"
        return 0
    fi

    if [[ "_e" == "$1" ]]; then
        _edit ${HOME}/.st.rc.d/.st.sh.d/_sd2d.sh
    fi

    if [[ "_t" == "$1" ]]; then
        _edit ${HOME}/.st.rc.d/.st.tst.d/_sd2d.tst.d
    fi

    if [[ -z "$3" ]]; then
        echo "" >&2
    fi

    #! ptr_path
    # local ptr_path="$1"
    # ptr_path="$("${_abs_path}" "${PPWD}" "ptr_path")"
    #[[ptr_path]]

    if ! [[ -d "$3" ]]; then
        echo "in fs=file://${HOME}/.st.rc.d/.st.sh.d/_sd2d.sh , line=${LINENO}, ${FUNCNAME}() : NOT_DIR : 'file://$3' : ${hint} : return 1" >&2
        return 1
    fi

    # for

    return 0

}
