#!/bin/bash

_sd2d() {

    local FNN=${FUNCNAME[0]}
    local PPWD=$PWD
    local ARGS=("$@")
    local NARGS=$#

    echo -e "${CYAN}--- start : ${FUNCNAME}() $@ ---${NORMAL}" #sistem info mesage

    if [[ "-h" == "$1" ]]; then
        echo -e "
MAIN: ${FUNCNAME} :: cp dir \$3 to $(namedir \$3) with replace \$1 to \$2 in files and name node
\$1 
[, \$2]
CNTL: 
    _e : body fn : _edit ${HOME}/.st.rc.d/.st.sh.d/_sd2d.sh
    _t : tst_dir : _edit ${HOME}/.st.rc.d/.st.tst.d/_sd2d.tst.d

NB!!: escaping in \$2 '\[' '\]' '\\\$' '\^' '\\\\\'
EXAM: 
    ${FUNCNAME}
"
        return 0
    fi

    if [[ "_e" == "$1" ]]; then
        _edit ${HOME}/.st.rc.d/.st.sh.d/_sd2d.sh
        return 0
    fi

    if [[ "_t" == "$1" ]]; then
        _edit ${HOME}/.st.rc.d/.st.tst.d/_sd2d.tst.d
        return 0
    fi

    if [[ -z "$3" ]]; then
        echo "\$3 NOT_DEFINE return 1" >&2
        return 1
    fi

    #! ptr_path
    local init_dir="$3"
    init_dir="$("${_abs_path}" "${PPWD}" "init_dir")"
    #[[ptr_path]]

    if ! [[ -d "$init_dir" ]]; then
        echo "in fs= file://${HOME}/.st.rc.d/.st.sh.d/_sd2d.sh , line=${LINENO}, ${FUNCNAME}() : NOT_DIR : 'file://$init_dir' : ${hint} : return 1" >&2
        return 1
    fi

    local inserter=$1
    local reciver=$2

    local init_dir_name=$(basename $init_dir)
    local init_dir_base=$(dirname $init_dir)

    local result_dir_name=$(_s2se $inserter $reciver $init_dir_name)

    # echo -e "${HLIGHT}--- exec: cp -r ${init_dir_base}/${init_dir_name}/. ${init_dir_base}/${result_dir_name} ---${NORMAL}" #start files
    if [[ -d ${init_dir_base}/${result_dir_name} ]]; then
        echo "in fs= file://${HOME}/.st.rc.d/.st.sh.d/_sd2d.sh , line=${LINENO}, ${FNN}() : DIR_EXIST: 'file://${init_dir_base}/${result_dir_namer}' : ${hint} : return 1" >&2
        return 1
    fi

    echo -e "${HLIGHT}--- exec: mkdir -v ${init_dir_base}/${result_dir_name} ---${NORMAL}" #start files
    mkdir -v ${init_dir_base}/${result_dir_name}

    echo -e "${HLIGHT}--- exec: cp -rv ${init_dir_base}/${init_dir_name}/. ${init_dir_base}/${result_dir_name} ---${NORMAL}" #start files
    cp -rv ${init_dir_base}/${init_dir_name}/. ${init_dir_base}/${result_dir_name}

    local result_dir=${init_dir_base}/${result_dir_name}

    return 0

    _in_fn_1_sd2d() {

        if ! [[ -d "$1" ]]; then
            echo "in fs=file://${HOME}/.st.rc.d/.st.sh.d/_sd2d.sh, line=${LINENO}, pwd=${PWD} fn=${FUNCNAME}() : NOT_DIR : '$1'" >&2
            return 1
        fi

        local item
        for item in $(_d2e "$1"); do
            if echo $item | grep $inserter; then
                echo -e "${HLIGHT}--- exec: echo $item | sed "$inserter | $reciver | g" ---${NORMAL}" #start files
                echo $item | sed "$inserter|$reciver|g"
            fi
        done

    }

    _in_fn_1_sd2d ${result_dir}

    if ! _in_fn_1_sd2d $init_dir; then
        echo "in fs=file://${HOME}/.st.rc.d/.st.sh.d/_sd2d.sh, line=${LINENO}, pwd=${PWD} fn=${FUNCNAME}() : EXEC_FAIL : '_in_fn_1_sd2d $init_dir' return 1" >&2
        return 1
    fi

    return 0

}
