#!/bin/bash

_ret2e() {

    if [ "-h" == "$1" ]; then
        echo -e "
\$1 
[, \$2]
"
        return 0
    fi

    "$@" &>/dev/null
    echo $?

}
