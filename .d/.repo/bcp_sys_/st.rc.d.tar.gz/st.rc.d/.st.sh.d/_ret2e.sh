#!/bin/bash

_ret2e() {

    "$@" &>/dev/null
    echo $?

}
