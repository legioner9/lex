#!/bin/bash

_ret2e() {

    echo -e "${CYAN}--- start : ${FUNCNAME}() $@ ---${NORMAL}" #sistem info mesage

    if [ "-h" == "$1" ]; then
        echo -e "
MAIN: ${FUNCNAME} :: 
\$1 
[, \$2]
"
        return 0
    fi

    "$@" &>/dev/null
    return $?

}
