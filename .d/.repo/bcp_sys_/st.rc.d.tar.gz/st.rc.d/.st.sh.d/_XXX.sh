#!/bin/bash

_XXX() {

    if [ "-h" == "$1" ]; then
        echo -e "
\$1 
[, \$2]
"
        return 0
    fi

    return 0

}
