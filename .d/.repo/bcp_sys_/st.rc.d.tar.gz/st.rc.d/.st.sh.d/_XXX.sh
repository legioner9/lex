#!/bin/bash

_XXX() {

    echo -e "${CYAN}--- start : ${FUNCNAME}() $@ ---${NORMAL}" #sistem info mesage

    if [ "-h" == "$1" ]; then
        echo -e "
MAIN: ${FUNCNAME} :: 
\$1 
[, \$2]
"
        return 0
    fi
 
    return 0

}
