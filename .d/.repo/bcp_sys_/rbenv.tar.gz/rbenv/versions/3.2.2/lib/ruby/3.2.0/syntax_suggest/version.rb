# frozen_string_literal: true

module SyntaxSuggest
  VERSION = "1.0.2"
end
