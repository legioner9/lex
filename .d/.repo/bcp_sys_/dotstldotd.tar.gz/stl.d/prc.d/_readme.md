# `~/.stl.d/prc.d`

- `~/.stl.d/prc.d/boot_stl_const.d` :: define const for all stl (felf start fn)
- `~/.stl.d/prc.d/boot_stl_fn.d` :: define fn for use for boot stl
- `~/.stl.d/prc.d/stl_util.d` :: define fn for temporary maintenacce - NOT STABLE