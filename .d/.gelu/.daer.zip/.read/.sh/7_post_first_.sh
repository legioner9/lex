#!/bin/bash

echo -e "${GREEN} start 7_post_first_.sh ${NORMAL}" #print variable

. ${PLT_PATH}/.d/.etc/nginx/cp_scena_1_conf.sh
